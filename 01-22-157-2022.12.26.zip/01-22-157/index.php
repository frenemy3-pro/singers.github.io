<!DOCTYPE html>
<html lang="en">

    <link rel="stylesheet" href="style.css">
    <script type="text/javascript" href="text.js">
    </script>
    <title>Найуспішніші музиканти в історії</title>
</head>

<body bgcolor="#FFFFFF">

<table>
    
<tr>
<td align = "center">
	<h2 onclick="myFunction(this, 'rgb(246, 219, 219)')"> <a href="indexaboutmichael.html"> Майкл Джексон </a></td></h2>
    <script>
function myFunction(element, color) {
  element.style.background = "rgb(246, 219, 219)";
}
</script>
<td align = "center">
    <h2 onclick="myFunction(this, 'rgb(246, 219, 219)')"> <a href="indexaboutelvis.html"> Елвіс Преслі </a></h2></td>
    <script>
function myFunction(element, color) {
  element.style.background = "rgb(246, 219, 219)";
}
</script>
<td align = "center">
    <h2 onclick="myFunction(this, 'rgb(246, 219, 219)')"> <a href="indexaboutfreddy.html"> Фредді Мерк'юрі </a></h2></td>
    <script>
function myFunction(element, color) {
  element.style.background = "rgb(246, 219, 219)";
}
</script>
</tr>

<tr>
    <td align = "center"> <img src="https://n1s2.starhit.ru/3c/ec/93/3cec9316a492bc3bfc94706ab4182e8f/444x460_0_d379425c9386853bcecd88874e07cdc6@480x497_0xac120003_8098173331561369530.jpg" width="100%" alt="зображення1"></td>
    <td align = "center"> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Elvis_Presley_1970.jpg/800px-Elvis_Presley_1970.jpg" width="45%" alt="зображення2"></td>
    <td align = "center"> <img src="https://hroniky.com/content/thumbs/evza5o/1200x630/bz/46/bz46aqlmmqrpmlwbx775zpowlyies2y2.jpg" width="79%" alt="зображення3"></td>
</tr>


</table>

</div>

</body>

</html>
